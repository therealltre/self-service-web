(() => {
var exports = {};
exports.id = 433;
exports.ids = [433];
exports.modules = {

/***/ 173:
/***/ (() => {

// import { useRouter } from "next/router";
// import LocalStorageService from "../api/token";
// const axios = require("axios");
// const API_URL = "https://apiib.newvifinancial.com"; // Replace with your API URL
// export default async function loginHandler(req, res) {
//   const router = useRouter();
//   if (req.method === "POST") {
//     const { merchant_number, password } = req.body;
//     // Make the API call to verify the login credentials
//     try {
//       const response = await axios.post(
//         `${API_URL}/users/token`,
//         {
//           merchant_number,
//           password
//         },
//         {
//           headers: {
//             Authorization: "Token " + LocalStorageService.getAccessToken(),
//             "content-type": "application/json",
//             Accept: "application/json"
//           }
//         }
//       );
//       // Handle the API response accordingly
//       if (response.data.success) {
//         // Login successful
//         res.status(200).json({ message: "Login successful" });
//         router.push({ pathname: "/loan", query: values });
//       } else {
//         // Login failed
//         res.status(401).json({ message: "Invalid credentials" });
//       }
//     } catch (error) {
//       // Handle API call error
//       res.status(500).json({ message: "Internal server error" });
//     }
//   } else {
//     // Method not allowed
//     res.status(405).json({ message: "Method not allowed" });
//   }
// }


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(173));
module.exports = __webpack_exports__;

})();