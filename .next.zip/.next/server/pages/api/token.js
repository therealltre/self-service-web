"use strict";
(() => {
var exports = {};
exports.id = 857;
exports.ids = [857];
exports.modules = {

/***/ 851:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// LocalStorageService.js
const LocalStorageService = function() {
    var _service;
    function _getService() {
        if (!_service) {
            _service = this;
            return _service;
        }
        return _service;
    }
    function _setToken(tokenObj) {
        localStorage.setItem("access_token", tokenObj.access); // localStorage.setItem('refresh_token', tokenObj.refresh_token);
    }
    function _getAccessToken() {
        return localStorage.getItem("token");
    }
    function _getXbsToken() {
        return localStorage.getItem("xbs_token");
    }
    function _getRefreshToken() {
        return localStorage.getItem("refresh_token");
    }
    function _clearToken() {
        localStorage.removeItem("access_token");
        localStorage.removeItem("refresh_token");
    }
    return {
        getService: _getService,
        getXbsToken: _getXbsToken,
        setToken: _setToken,
        getAccessToken: _getAccessToken,
        getRefreshToken: _getRefreshToken,
        clearToken: _clearToken
    };
}();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LocalStorageService);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(851));
module.exports = __webpack_exports__;

})();