"use strict";
(() => {
var exports = {};
exports.id = 802;
exports.ids = [802];
exports.modules = {

/***/ 121:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Success)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(853);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/failedImage.png
/* harmony default export */ const failedImage = ({"src":"/_next/static/media/failedImage.5b46b8e8.png","height":4000,"width":4000,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAYFBMVEX0urr0t7fzsLHzr6/zrq7ugILtdnfrVlnrVVgAAAD30ND3zc32y8zypKXxpKXxo6TxoaLxn6DwkZLvj5DvjI3vhofyq6zyqqvufH3ueXvvjo/ueXvsaWvsZGbpAADoAABPERkbAAAAGnRSTlMAAAAAAAAAAAAAAQEBXFxcXFzDw8PD+fn5+XFtHocAAABHSURBVHjaDcXHAYAgDADAUIIGULqFuv+Wep8D0nzfuCaw4Evxf/IctY5DAsZ13SsiYJrPOxOCdL217iRYFnIOzAIZoZQw9AGAkwOVxp4RwQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: external "@material-tailwind/react"
var react_ = __webpack_require__(715);
;// CONCATENATED MODULE: ./pages/failed.js





function Success() {
    const router = (0,router_.useRouter)();
    return /*#__PURE__*/ jsx_runtime_.jsx("main", {
        className: "h-screen flex items-center justify-center",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "bg-white rounded-lg lg:w-1/2 md:w-4/5 font-sans text-gray-700 shadow-lg border-gray-100 p-12 justify-center ",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex justify-center ",
                    id: "Logo",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: failedImage,
                        alt: "",
                        className: "mb-6 h-[150px] w-[150px]"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                    className: "text-2xl pb-4 font-sans flex justify-center ",
                    children: "Your loan request has failed."
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                    className: "text-xl pb-4 text-gray-500 font-sans flex justify-center",
                    children: [
                        "Please check the information you provided and try again",
                        " ",
                        router.query.merchant_number
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex justify-center mt-8",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                        type: "submit",
                        onClick: ()=>router.push({
                                pathname: "/"
                            }),
                        className: "bg-blue-700 text-sm text-white p-2  rounded-md w-1/2",
                        children: "Ok"
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 715:
/***/ ((module) => {

module.exports = require("@material-tailwind/react");

/***/ }),

/***/ 918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [636,675], () => (__webpack_exec__(121)));
module.exports = __webpack_exports__;

})();