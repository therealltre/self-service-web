"use strict";
(() => {
var exports = {};
exports.id = 2;
exports.ids = [2];
exports.modules = {

/***/ 550:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Success)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(853);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/successImage.png
/* harmony default export */ const successImage = ({"src":"/_next/static/media/successImage.a7b20416.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA6klEQVR42mOAAYdtYfUWWwNXW20NWu20PaIeLmG3NVTKdlvIPKDkf59t8f/dtkX/N9js/d9+W9g8m60hUgyO28K9LYGSKXtK/tWc6vnTd2n2n4rjbf+Mtvj+d90e5c1gtS1ol+vWqP9952f/XXF34//7Hx/9X35n41+77eH/bbYG72Kw3hq0C2Rs78VZf59/efl//5Oj/+svTPgbuCvlv/kW/10MQAd5W24J/J9xuPJfx6Xpf9ouTf2Te7T2n/mWgP8gOQb7bUBHbg2ZB1LkuzPxv9+upP8gSZAYSA7Vm1sCVgONXQ1kw70JAHrLf0M6YPvwAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: external "@material-tailwind/react"
var react_ = __webpack_require__(715);
;// CONCATENATED MODULE: ./pages/success.js





function Success() {
    const router = (0,router_.useRouter)();
    return /*#__PURE__*/ jsx_runtime_.jsx("main", {
        className: "h-screen flex items-center justify-center",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "bg-white rounded-lg lg:w-1/2 md:w-4/5 font-sans text-gray-700 shadow-lg border-gray-100 p-12 justify-center ",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex justify-center ",
                    id: "Logo",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: successImage,
                        alt: "",
                        className: "mb-6 h-[100px] w-[100px]"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                    className: "text-2xl pb-4 font-sans flex justify-center ",
                    children: [
                        "Your loan request is being processed.",
                        " "
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                    className: "text-xl pb-4 text-gray-500 font-sans flex justify-center",
                    children: [
                        "Please wait for SMS confirmation. ",
                        router.query.mobile_no
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex justify-center mt-8",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                        type: "submit",
                        onClick: ()=>router.push({
                                pathname: "/"
                            }),
                        className: "bg-blue-700 text-sm text-white p-2  rounded-md w-1/2",
                        children: "Ok"
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 715:
/***/ ((module) => {

module.exports = require("@material-tailwind/react");

/***/ }),

/***/ 918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [636,675], () => (__webpack_exec__(550)));
module.exports = __webpack_exports__;

})();